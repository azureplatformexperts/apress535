
$vpnClientPool = "10.1.0.0/24"
$vpnGWName = "OPSGW1"
$rgName = "OpsVNETRmRG"
$rootCertName = "P2SRoot.cer" 

$publicCertData = "[REPLACE WITH PUBLIC KEY VALUE]" 

# Get the current virtual network configuration 
$vpnGW = Get-AzureRmVirtualNetworkGateway -ResourceGroupName $rgName `
                                          -Name $vpnGWName


# This is the IP range VPN clients will use to connect to the gateway
Set-AzureRmVirtualNetworkGatewayVpnClientConfig `
             -VirtualNetworkGateway $vpnGW `
             -VpnClientAddressPool $vpnClientPool  

# install certificate in the gateway
Add-AzureRmVpnClientRootCertificate `
            -VpnClientRootCertificateName $rootCertName `
            -VirtualNetworkGatewayName $vpnGWName `
            -ResourceGroupName $rgName `
            -PublicCertData $publicCertData 
